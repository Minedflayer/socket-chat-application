package com.message_app.demo.rooms.repo;

import com.message_app.demo.rooms.domain.Conversation;
import com.message_app.demo.rooms.domain.ConversationMember;
import jakarta.transaction.Transactional;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class DmService {
    private final ConversationRepository convs;
    private final ConversationMemberRepository members;

    public DmService(ConversationRepository convs, ConversationMemberRepository members) {
        this.convs = convs;
        this.members = members;
    }

    @Transactional
    public Conversation getOrCreateDm(long u1, long u2) {
        if (u1 == u2) throw new IllegalArgumentException("DM with self not allowed");
        long a = Math.min(u1, u2), b = Math.max(u1, u2);
        String key = a + ":" + b;

        return convs.findByDmKey(key).orElseGet(() -> createDm(key, a, b));
    }

    private Conversation createDm(String key, long a, long b) {
        try {
            Conversation c = new Conversation();
            c.setType("DM");
            c.setDmKey(key);
            c = convs.saveAndFlush(c);

            ConversationMember m1 = new ConversationMember();
            m1.setConversation(c);
            m1.setUserId(a);
            members.save(m1);

            ConversationMember m2 = new ConversationMember();
            m2.setConversation(c);
            m2.setUserId(b);
            members.save(m2);

            return c;
        } catch (DataIntegrityViolationException e) {
            return convs.findByDmKey(key).orElseThrow();
        }
    }

}
