package com.message_app.demo.security;
// Authenticate on STOMP CONNECT (ChannelInterceptor)

import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.messaging.*;
import org.springframework.messaging.simp.stomp.*;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ChannelInterceptor that runs when STOMP frames pass through the inbound channel.
 * Responsibilities:
 *  - On CONNECT: extract "Authorization: Bearer <jwt>" from headers.
 *  - Validate JWT using JwtService.
 *  - Build a Spring Security Authentication (UsernamePasswordAuthenticationToken).
 *  - Attach that Authentication as the session "user" (Principal).
 * Once set, the user is available as Principal in @MessageMapping methods,
 * and Spring Messaging Security can enforce authorization rules.
 */
@Component
public class StompAuthChannelInterceptor implements ChannelInterceptor {
    private static final String AUTH_KEY = "auth";
private static final Logger log = LoggerFactory.getLogger(StompAuthChannelInterceptor.class);
private final JwtService jwt;

public StompAuthChannelInterceptor(JwtService jwt) {
    this.jwt = jwt;
}

@Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
    var sha = StompHeaderAccessor.wrap(message);

    // Initial handshake. Only inspects CONNECT frames
    if(sha.getCommand() == StompCommand.CONNECT) {
        var authz = first(sha.getNativeHeader("Authorization"));
        if (authz == null || !authz.startsWith("Bearer")) {
            throw new IllegalArgumentException("Missing authorization");
        }
        log.debug("auth user on {} → {}", sha.getCommand(), sha.getUser());


        var token = authz.substring("Bearer".length()).trim();
        var jws = jwt.parse(token);
        var username = jwt.userName(jws);
        var authorities = jwt.roles(jws).stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
        var auth = new UsernamePasswordAuthenticationToken(username, "N/A", authorities);
        // Attach authenticated user to this STOMP session
        sha.setUser(auth);
        if (sha.getSessionAttributes() != null) {
            sha.getSessionAttributes().put(AUTH_KEY, auth); // cache for later frames
        }
    } else {
        if(sha.getUser() == null && sha.getSessionAttributes() != null) {
            Object cached = sha.getSessionAttributes().get(AUTH_KEY);
            if(cached instanceof Principal) {
                sha.setUser((Principal) cached);
            }
        }


        /*sha.getSessionAttributes().put("user", username);
        log.info("event=stomp_connect user{} roles{}", username, authorities);*/

        }

    return message;

    }

    private static String first(List<String> xs) {
        return (xs != null && !xs.isEmpty()) ? xs.get(0) : null;
    }




}
