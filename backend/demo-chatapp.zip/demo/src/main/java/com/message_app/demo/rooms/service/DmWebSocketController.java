package com.message_app.demo.rooms.service;

import com.message_app.demo.rooms.domain.Message;
import com.message_app.demo.rooms.repo.DmService;
import com.message_app.demo.rooms.repo.MessageRepository;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.time.Instant;

@Controller
public class DmWebSocketController {
    public record ChatIn(String content) {

    }
    public record ChatOut(Long conversationId, String sender, String content, Instant sentAt) {

    }
    private final SimpMessagingTemplate broker;
    private final DmService dmService;
    private final MessageRepository messages;
    public DmWebSocketController(SimpMessagingTemplate broker, DmService dmService, MessageRepository messages) {
        this.broker = broker;
        this.dmService = dmService;
        this.messages = messages;
    }
    @MessageMapping("/dm/{otherUserId}/send")
    public void send(@DestinationVariable Long otherUserId, ChatIn in, Principal principal) {
        String meName = principal.getName();
        //long meId = userIdFromPrincipal(principal);

        var conv = dmService.getOrCreateDm(meId, otherUserId);
        var m = new Message();
        m.setConversation(conv);
        m.setSenderId(meName);
        m.setContent(in.content());
        m = messages.save(m);

        var out = new ChatOut(conv.getId(),meName, m.getContent(), m.getSentAt());
        broker.convertAndSendToUser(meName,           "/queue/dm/" + conv.getId(), out);
        broker.convertAndSendToUser(otherUserId.toString(), "/queue/dm/" + conv.getId(), out);


    }

    private long userIdFromPrincipal(Principal p) {
        // adapt to your JwtService / Authentication
        return Long.parseLong(p.getName()); // or pull a custom claim; adjust to your app
    }
}
