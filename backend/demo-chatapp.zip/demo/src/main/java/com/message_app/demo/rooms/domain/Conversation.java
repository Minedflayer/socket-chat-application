package com.message_app.demo.rooms.domain;

import jakarta.persistence.*;

@Entity @Table(name="conversations")
public class Conversation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 8)
    private String type = "DM";

    // Canoncial pair key: minUserId:maxUserId (unique -> one DM per pair)
    @Column(unique = true, length = 64)
    private String dmKey;

    public Conversation() {
    }

    public void setDmKey(String key) {
    }

    public void setType(String dm) {
    }

    public Long getId() {
    }

    //getter/setters


}
