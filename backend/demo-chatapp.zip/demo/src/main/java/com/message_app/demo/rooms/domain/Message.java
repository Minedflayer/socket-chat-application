package com.message_app.demo.rooms.domain;

import jakarta.persistence.*;

import java.time.Instant;

@Entity @Table(name="messages")
public class Message {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false) private Conversation conversation;
    @Column(nullable = false) private String senderId;
    @Column(nullable = false, length = 2000) private String content;
    @Column(nullable = false, updatable = false) private Instant sentAt = Instant.now();

    public Long getId() {
        return id;
    }

    public Conversation getConversation() {
        return conversation;
    }
    public void setConversation(Conversation conversation) {
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public String getSenderId() {
        return senderId;
    }
    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }
    public Instant getSentAt() {
        return sentAt;
    }
    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }





}
