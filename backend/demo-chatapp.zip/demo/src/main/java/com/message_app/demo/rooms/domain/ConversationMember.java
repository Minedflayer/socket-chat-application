package com.message_app.demo.rooms.domain;

import jakarta.persistence.*;

@Entity
@Table(name="conversation_members",
        uniqueConstraints=@UniqueConstraint(columnNames={"conversation_id","user_id"}))
public class ConversationMember {
    @Id @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "conversation_id")
    private Conversation conversation;

    @Column(nullable = false) private Long userId;

    public void setConversation(Conversation c) {
    }

    public void setUserId(long a) {
    }




}
