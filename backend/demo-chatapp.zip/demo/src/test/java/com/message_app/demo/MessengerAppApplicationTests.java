package com.message_app.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessengerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
